<?php

include_once(__DIR__ . "/../../controller/AlunoController.php");

//Carrega a lista de alunos
$alunoCont = new AlunoController;
$alunos = $alunoCont->listar();
print_r($alunos);

include_once(__DIR__ . "/../include/header.php");
?>

<h3>Listagem de alunos</h3>
<a href="inserir.php">Inserir</a>
<table>

    <tr>
        <td>ID</td>
        <td>Nome</td>
        <td>Idade</td>
        <td>Estrangeiro</td>
        <td>Curso</td>

        <?php foreach ($alunos as $a): ?>
    <tr>
        <td><?= $a->getId() ?></td>
        <td><?= $a->getNome() ?></td>
        <td><?= $a->getIdade() ?></td>
        <td><?= $a->getEstrangeiroDescr() ?></td>
        <td><?= $a->getCurso() ?></td>


    </tr>


<?php endforeach; ?>


</tr>





</table>





<?php
include_once(__DIR__ . "/../include/footer.php");
?>